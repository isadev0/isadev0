# ps-inventory
Project-Sloth's FiveM Inventory System Redesigned to Look Like NoPixel 4.0
